# Программа загадывает число от 0 до 1000. Необходимо угадать число за 10 попыток. Программа
# должна подсказывать «больше» или «меньше» после каждой попытки. Для генерации случайного
# числа используйте код:
# from random import randint
# num = randint(LOWER_LIMIT, UPPER_LIMIT)

from random import randint

LOWER_LIMIT = 0
UPPER_LIMIT = 1000
MAX_ATTEMPTS = 10

target_number = randint(LOWER_LIMIT, UPPER_LIMIT)

print("Программа загадала число от", LOWER_LIMIT, "до", UPPER_LIMIT)

attempts = 0

while attempts < MAX_ATTEMPTS:
    guess = int(input("Попытка {}: Введите ваше предположение: ".format(attempts + 1)))

    if guess < target_number:
        print("Больше")
    elif guess > target_number:
        print("Меньше")
    else:
        print("Вы угадали! Загаданное число было", target_number)
        break
    attempts += 1

if attempts == MAX_ATTEMPTS:
    print("Вы исчерпали все попытки. Загаданное число было", target_number)