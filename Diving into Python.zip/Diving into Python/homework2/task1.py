# Задание No6
# Напишите программу банкомат.
# ✔ Начальная сумма равна нулю
# ✔ Допустимые действия: пополнить, снять, выйти
# ✔ Сумма пополнения и снятия кратны 50 у.е.
# ✔ Процент за снятие — 1.5% от суммы снятия, но не менее 30 и не более 600 у.е.
# ✔ После каждой третей операции пополнения или снятия начисляются проценты - 3%
# ✔ Нельзя снять больше, чем на счёте
# ✔ При превышении суммы в 5 млн, вычитать налог на богатство 10% перед каждой операцией, даже ошибочной
# ✔ Любое действие выводит сумму денег 

class BankAccount:
    def __init__(self):
        self.balance = 0
        self.operations_count = 0
        self.wealth_tax_threshold = 5000000

    def deposit(self, amount):
        self.balance += amount
        self.operations_count += 1
        self.calculate_interest()
        self.display_balance()

    def withdraw(self, amount):
        if amount <= self.balance:
            withdrawal_fee = max(30, min(amount * 0.015, 600))
            self.balance -= amount + withdrawal_fee
            self.operations_count += 1
            self.calculate_interest()
            self.display_balance()
        else:
            print("Недостаточно средств на счете.")
            self.display_balance()

    def calculate_interest(self):
        if self.operations_count % 3 == 0:
            self.balance *= 1.03  # 3% interest after every 3rd operation

        if self.balance > self.wealth_tax_threshold:
            wealth_tax = self.balance * 0.1
            self.balance -= wealth_tax

    def display_balance(self):
        print("Текущий баланс: {:.2f} у.е.".format(self.balance))

def main():
    account = BankAccount()

    while True:
        print("\nДоступные действия:")
        print("1. Пополнить счет")
        print("2. Снять деньги")
        print("3. Выйти")
        choice = int(input("Выберите действие: "))
        if choice == 1:
            amount = int(input("Введите сумму для пополнения (кратную 50): "))
            if amount % 50 == 0:
                account.deposit(amount)
            else:
                print("Сумма для пополнения должна быть кратна 50.")
        elif choice == 2:
            amount = int(input("Введите сумму для снятия (кратную 50): "))
            if amount % 50 == 0:
                account.withdraw(amount)
            else:
                print("Сумма для снятия должна быть кратна 50.")
        elif choice == 3:
            break
        else:
            print("Неверный выбор. Попробуйте снова.")

if __name__ == "__main__":
    main()
