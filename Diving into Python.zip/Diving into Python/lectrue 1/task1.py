# Откроем IDE для живого примера, а потом вернёмся к перечню ниже
#   Верно                       Не верно
# first_name                    1_name
# user_1,                       User_1
# request                       Orequest
# _tmp_name                     tmpName
# min_step_shift                minStep_shift

# Константы
# Дополнительных команд для создания констант в языке Python нет!
#     Создаваемые                             Встроенные
# MAX COUNT = 1000                          True - истина
# ZERO = 0                                  False - ложь
# DATA_AFTER_DELETE = 'No data              None - ничего
# DAY = 60 * 60 * 24

# Функция id() возвращает адрес объекта в оперативной памяти вашего компьютера
# a = 5
# print(id(a))

# a = "hello world"
# print(id(a))

# a = 42.0 * 3.141592 / 2.71828
# print(id(a))